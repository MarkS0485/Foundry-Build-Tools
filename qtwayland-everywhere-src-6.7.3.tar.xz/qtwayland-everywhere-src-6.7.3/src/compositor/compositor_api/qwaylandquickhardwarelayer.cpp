// Copyright (C) 2018 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR GPL-3.0-only

#include "qwaylandquickhardwarelayer_p.h"

#include <QtWaylandCompositor/private/qwlhardwarelayerintegration_p.h>
#include <QtWaylandCompositor/private/qwlhardwarelayerintegrationfactory_p.h>

#include <QtCore/private/qobject_p.h>
#include <QMatrix4x4>

QT_BEGIN_NAMESPACE

class QWaylandQuickHardwareLayerPrivate : public QObjectPrivate
{
    Q_DECLARE_PUBLIC(QWaylandQuickHardwareLayer)
public:
    QtWayland::HardwareLayerIntegration *layerIntegration();
    QWaylandQuickItem *m_waylandItem = nullptr;
    int m_stackingLevel = 0;
    QMatrix4x4 m_matrixFromRenderThread;
    static QtWayland::HardwareLayerIntegration *s_hardwareLayerIntegration;
};

QtWayland::HardwareLayerIntegration *QWaylandQuickHardwareLayerPrivate::s_hardwareLayerIntegration = nullptr;

QtWayland::HardwareLayerIntegration *QWaylandQuickHardwareLayerPrivate::layerIntegration()
{
    if (!s_hardwareLayerIntegration) {
        QStringList keys = QtWayland::HardwareLayerIntegrationFactory::keys();

        QString environmentKey = QString::fromLocal8Bit(qgetenv("QT_WAYLAND_HARDWARE_LAYER_INTEGRATION").constData());
        if (!environmentKey.isEmpty()) {
            if (keys.contains(environmentKey)) {
                s_hardwareLayerIntegration = QtWayland::HardwareLayerIntegrationFactory::create(environmentKey, QStringList());
            } else {
                qWarning() << "Unknown hardware layer integration:" << environmentKey
                           << "Valid layer integrations are" << keys;
            }
        } else if (!keys.isEmpty()) {
            s_hardwareLayerIntegration = QtWayland::HardwareLayerIntegrationFactory::create(keys.first(), QStringList());
        } else {
            qWarning() << "No wayland hardware layer integrations found";
        }
    }

    return s_hardwareLayerIntegration;
}

/*!
 * \qmltype WaylandHardwareLayer
 * \inqmlmodule QtWayland.Compositor
 * \preliminary
 * \brief Makes a parent WaylandQuickItem use hardware layers for rendering.
 *
 * This item needs to be a descendant of a WaylandQuickItem or a derivative,
 * (i.e. ShellSurfaceItem or similar)
 *
 * The Surface of the parent WaylandQuickItem will be drawn in a hardware specific way instead
 * of the regular way using the QtQuick scene graph. On some platforms, the WaylandQuickItem's
 * current buffer and the scene graph can be blended in a separate step. This makes it possible for
 * clients to update continuously without triggering a full redraw of the compositor scene graph for
 * each frame.
 *
 * The preferred hardware layer integration may be overridden by setting the
 * QT_WAYLAND_HARDWARE_LAYER_INTEGRATION environment variable.
 */

QWaylandQuickHardwareLayer::QWaylandQuickHardwareLayer(QObject *parent)
    : QObject(*new QWaylandQuickHardwareLayerPrivate(), parent)
{
}

QWaylandQuickHardwareLayer::~QWaylandQuickHardwareLayer()
{
    Q_D(QWaylandQuickHardwareLayer);
    if (d->layerIntegration())
        d->layerIntegration()->remove(this);
}

/*!
 * \qmlproperty int QtWayland.Compositor::WaylandHardwareLayer::stackingLevel
 *
 * This property holds the stacking level of this hardware layer relative to other hardware layers,
 * and can be used to sort hardware layers. I.e. a layer with a higher level is rendered on top of
 * one with a lower level.
 *
 * Layers with level 0 will be drawn in an implementation defined order on top of the compositor
 * scene graph.
 *
 * Layers with a level below 0 are drawn beneath the compositor scene graph, if supported by the
 * hardware layer integration.
 */
int QWaylandQuickHardwareLayer::stackingLevel() const
{
    Q_D(const QWaylandQuickHardwareLayer);
    return d->m_stackingLevel;
}

void QWaylandQuickHardwareLayer::setStackingLevel(int level)
{
    Q_D(QWaylandQuickHardwareLayer);
    if (level == d->m_stackingLevel)
        return;

    d->m_stackingLevel = level;
    emit stackingLevelChanged();
}

QWaylandQuickItem *QWaylandQuickHardwareLayer::waylandItem() const
{
    Q_D(const QWaylandQuickHardwareLayer);
    return d->m_waylandItem;
}

void QWaylandQuickHardwareLayer::classBegin()
{
    Q_D(QWaylandQuickHardwareLayer);
    for (QObject *p = parent(); p != nullptr; p = p->parent()) {
        if (auto *waylandItem = qobject_cast<QWaylandQuickItem *>(p)) {
            d->m_waylandItem = waylandItem;
            break;
        }
    }
}

void QWaylandQuickHardwareLayer::componentComplete()
{
    Q_D(QWaylandQuickHardwareLayer);
    Q_ASSERT(d->m_waylandItem);
    if (auto integration = d->layerIntegration())
        integration->add(this);
    else
        qWarning() << "No hardware layer integration. WaylandHarwareLayer has no effect.";
}

void QWaylandQuickHardwareLayer::setSceneGraphPainting(bool enable)
{
    waylandItem()->setPaintEnabled(enable);
}

// This should be called if QWaylandQuickHardwareLayer used as a native instance, not a qml component.
void QWaylandQuickHardwareLayer::initialize()
{
    classBegin();
    componentComplete();
}

QT_END_NAMESPACE

#include "moc_qwaylandquickhardwarelayer_p.cpp"
