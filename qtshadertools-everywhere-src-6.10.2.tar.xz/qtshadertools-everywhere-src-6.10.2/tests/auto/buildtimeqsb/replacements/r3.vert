Test r3
