TEMPLATE = subdirs

SUBDIRS = translations
